from setuptools import setup

setup(
    name="HousePricePrediction",
    version="0.1",
    author="Sayantan",
    initial_requires=["numpy", "pandas", "scikit-learn"],
)
